package com.najishab.aether.core

import java.io.File
import java.util.concurrent.TimeUnit
import org.json.JSONObject

/**
 * Endpoint data as reported by the `warpscout -json` scanner (see json.go in
 * the vendored warpscout core). Field names mirror the JSON keys 1:1.
 */
data class ScoutResult(
    val endpoint: String,
    val ip: String,
    val working: Boolean,
    val endpointPingMs: Double,
    val tunPingMs: Double,
    val tunPingMeasured: Boolean,
    val lossPct: Double,
    val seenAs: String,
    val seenAsIso: String,
    val node: String,
    val nodeLocation: String,
)

data class ScoutReport(
    val proto: String,
    val workingCount: Int,
    val probedCount: Int,
    val results: List<ScoutResult>,
)

/** What the user picked in the scanner screen, before it becomes CLI args. */
data class ScoutOptions(
    val protocol: ScoutProtocol,
    val mode: ScoutMode,
    val ipVersion: ScoutIpVersion,
    val port: Int? = null,
    /**
     * AmneziaWG only: generate a fresh init packet (I1) mimicking this
     * protocol instead of the built-in default (an iCloud probe). `quic` is
     * what warpscout's own "no working endpoints" message suggests trying
     * first on networks that filter plain WireGuard/AWG's default I1 (e.g.
     * Iranian DPI) — see i1gen.go upstream. Null = leave the default I1.
     */
    val genI1: ScoutI1Profile? = null,
)

enum class ScoutProtocol { WIREGUARD, AMNEZIAWG, MASQUE, MASQUE_H2 }

/** `-gen-i1` profiles warpscout supports (i1gen.go). */
enum class ScoutI1Profile { QUIC, DNS, SIP, STUN, RANDOM }
enum class ScoutMode { STANDARD, DURABLE, FULL }
enum class ScoutIpVersion { V4, V6 }

sealed class ScoutOutcome {
    data class Progress(val line: String) : ScoutOutcome()
    data class Done(val report: ScoutReport) : ScoutOutcome()
    data class Failed(val message: String) : ScoutOutcome()
}

/**
 * Runs the vendored `warpscout` scanner (shipped as libwarpscout.so, same
 * jniLibs trick as [AetherProcess]) as a child process and parses its `-json`
 * output into [ScoutReport]. One WARP account is registered once and reused
 * for every scan, exactly like the desktop CLI's own `warpscout-account.json`.
 */
class WarpScoutRunner(
    private val nativeLibDir: String,
    private val workingDir: File,
) {
    private val accountFile = File(workingDir, "warpscout-account.json")
    private var scanProcess: Process? = null

    private fun binary(): File {
        val bin = File(nativeLibDir, "libwarpscout.so")
        if (!bin.exists()) {
            throw IllegalStateException("Scanner binary missing: ${bin.absolutePath}")
        }
        return bin
    }

    private fun newProcessBuilder(args: List<String>): ProcessBuilder {
        val command = mutableListOf(binary().absolutePath).apply { addAll(args) }
        return ProcessBuilder(command)
            .directory(workingDir)
            .also {
                it.environment()["HOME"] = workingDir.absolutePath
                it.environment()["TMPDIR"] = workingDir.absolutePath
            }
    }

    /** True once a WARP account is cached on disk and ready for scanning. */
    fun isRegistered(): Boolean = accountFile.exists() && accountFile.length() > 0L

    /**
     * Registers a fresh WARP account if none is cached yet. Safe to call every
     * time — it is a cheap no-op once [isRegistered] is true. Runs on whatever
     * thread the caller uses; callers should dispatch to IO.
     */
    fun ensureRegistered(): Result<Unit> {
        if (isRegistered()) return Result.success(Unit)
        return runCatching {
            val args = listOf("register", "-plain", "-a", accountFile.absolutePath)
            val proc = newProcessBuilder(args).redirectErrorStream(true).start()
            val output = proc.inputStream.bufferedReader().readText()
            val exited = proc.waitFor(30, TimeUnit.SECONDS)
            DiagnosticsLog.i("scout", "register: $output")
            if (!exited) {
                proc.destroyForcibly()
                throw IllegalStateException("Registration timed out")
            }
            if (proc.exitValue() != 0 || !isRegistered()) {
                throw IllegalStateException("Registration failed: ${output.trim().takeLast(200)}")
            }
        }
    }

    private fun buildArgs(opts: ScoutOptions): List<String> {
        val args = mutableListOf(
            "scan", "-json", "-plain",
            "-a", accountFile.absolutePath,
            "-p", when (opts.protocol) {
                ScoutProtocol.WIREGUARD -> "wg"
                ScoutProtocol.AMNEZIAWG -> "awg"
                ScoutProtocol.MASQUE -> "masque"
                ScoutProtocol.MASQUE_H2 -> "masque-h2"
            },
        )
        // AmneziaWG-only: swap the default I1 (an iCloud probe) for one of
        // warpscout's generated profiles. This is the fix upstream's own
        // "no working endpoints found" message points at on networks that
        // filter plain wg/awg's default handshake signature — see i1gen.go.
        if (opts.protocol == ScoutProtocol.AMNEZIAWG && opts.genI1 != null) {
            args += listOf(
                "-gen-i1",
                when (opts.genI1) {
                    ScoutI1Profile.QUIC -> "quic"
                    ScoutI1Profile.DNS -> "dns"
                    ScoutI1Profile.SIP -> "sip"
                    ScoutI1Profile.STUN -> "stun"
                    ScoutI1Profile.RANDOM -> "random"
                },
            )
        }
        when (opts.mode) {
            ScoutMode.STANDARD -> Unit
            ScoutMode.DURABLE -> args += listOf("-P", "-tun-ping-count", "10")
            ScoutMode.FULL -> args += "-f"
        }
        if (opts.ipVersion == ScoutIpVersion.V6) args += "-6"
        opts.port?.let { args += listOf("-port", it.toString()) }
        return args
    }

    private fun timeoutForMode(mode: ScoutMode): Long = when (mode) {
        ScoutMode.STANDARD -> 60_000L
        ScoutMode.DURABLE -> 120_000L
        ScoutMode.FULL -> 300_000L
    }

    /** Stops a scan started by [scan], if one is running. Safe to call anytime. */
    fun cancel() {
        val proc = scanProcess ?: return
        scanProcess = null
        runCatching {
            proc.destroy()
            if (!proc.waitFor(300, TimeUnit.MILLISECONDS)) proc.destroyForcibly()
        }
    }

    /**
     * Runs one scan to completion and returns the parsed report. Blocking —
     * call from a background dispatcher. [onProgress] receives raw stderr
     * lines (endpoint counters etc.) purely for a live "N tested" label; it is
     * best-effort and never affects the parsed result.
     */
    fun scan(opts: ScoutOptions, onProgress: (String) -> Unit = {}): Result<ScoutReport> = runCatching {
        val args = buildArgs(opts)
        val proc = newProcessBuilder(args).start()
        scanProcess = proc
        DiagnosticsLog.i("scout", "scan args: ${args.joinToString(" ")}")

        val stderrLines = mutableListOf<String>()
        val stderrThread = Thread({
            runCatching {
                proc.errorStream.bufferedReader().useLines { lines ->
                    lines.forEach {
                        synchronized(stderrLines) { stderrLines.add(it) }
                        onProgress(it)
                    }
                }
            }
        }, "warpscout-stderr").apply { isDaemon = true; start() }

        val stdout = proc.inputStream.bufferedReader().readText()
        val exited = proc.waitFor(timeoutForMode(opts.mode), TimeUnit.MILLISECONDS)
        stderrThread.join(1000)
        scanProcess = null

        val stderrText = synchronized(stderrLines) { stderrLines.joinToString("\n") }
        DiagnosticsLog.i(
            "scout",
            "scan exit=${if (exited) proc.exitValue() else "timeout"} stderr=$stderrText stdout=${stdout.take(500)}",
        )

        if (!exited) {
            proc.destroyForcibly()
            throw IllegalStateException("Scan timed out")
        }
        if (proc.exitValue() != 0 && stdout.isBlank()) {
            val detail = stderrText.trim().takeLast(300).ifBlank { "no output" }
            throw IllegalStateException("Scan failed with exit ${proc.exitValue()}: $detail")
        }
        parseReport(stdout)
    }

    private fun parseReport(json: String): ScoutReport {
        val root = JSONObject(json)
        val endpoints = root.getJSONArray("endpoints")
        val results = buildList {
            for (i in 0 until endpoints.length()) {
                val e = endpoints.getJSONObject(i)
                add(
                    ScoutResult(
                        endpoint = e.getString("endpoint"),
                        ip = e.optString("ip"),
                        working = e.optString("status") == "working",
                        endpointPingMs = e.optDouble("endpointPingMs", 0.0),
                        tunPingMs = e.optDouble("tunPingMs", 0.0),
                        tunPingMeasured = e.optBoolean("tunPingMeasured", false),
                        lossPct = e.optDouble("lossPct", 0.0),
                        seenAs = e.optString("seenAs"),
                        seenAsIso = e.optString("seenAsIso"),
                        node = e.optString("node"),
                        nodeLocation = e.optString("nodeLocation"),
                    ),
                )
            }
        }
        return ScoutReport(
            proto = root.optString("proto"),
            workingCount = root.optInt("working"),
            probedCount = root.optInt("probed"),
            results = results,
        )
    }
}
