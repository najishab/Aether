package com.najishab.aether

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.najishab.aether.core.DiagnosticsLog
import com.najishab.aether.core.ScoutI1Profile
import com.najishab.aether.core.ScoutIpVersion
import com.najishab.aether.core.ScoutMode
import com.najishab.aether.core.ScoutOptions
import com.najishab.aether.core.ScoutProtocol
import com.najishab.aether.core.ScoutResult
import com.najishab.aether.core.WarpScoutRunner
import com.najishab.aether.data.ProfileStore
import com.najishab.aether.data.ThemeMode
import com.najishab.aether.data.ThemeStore
import com.najishab.aether.model.EndpointMode
import com.najishab.aether.model.IpVersion
import com.najishab.aether.model.Noize
import com.najishab.aether.model.Protocol as ModelProtocol
import com.najishab.aether.ui.components.DropdownSelector
import com.najishab.aether.ui.components.LtrOutlinedTextField
import com.najishab.aether.ui.components.SegmentedSelector
import com.najishab.aether.ui.theme.AetherBlue
import com.najishab.aether.ui.theme.AetherCyan
import com.najishab.aether.ui.theme.AetherSuccess
import com.najishab.aether.ui.theme.AetherTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EndpointScannerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val themeStore = ThemeStore(applicationContext)
        val runner = WarpScoutRunner(applicationInfo.nativeLibraryDir, filesDir)
        val profileStore = ProfileStore(applicationContext)
        setContent {
            val themeMode by themeStore.mode.collectAsState(initial = ThemeMode.DARK)
            AetherTheme(themeMode = themeMode) {
                EndpointScannerScreen(
                    runner = runner,
                    profileStore = profileStore,
                    onBack = { finish() },
                )
            }
        }
    }
}

private enum class ScannerProtocol { MASQUE, MASQUE_H2, WIREGUARD, AMNEZIAWG }
private enum class ScannerMode { STANDARD, DURABLE, FULL }

private data class ScoutEndpoint(
    val endpoint: String,
    val endpointPing: String,
    val tunnelPing: String,
    val loss: String,
    val seenAs: String,
    val node: String,
    val nodeLocation: String,
    val healthy: Boolean,
)

private fun ScannerProtocol.isScoutable(): Boolean = true

private fun ScannerProtocol.toScoutProtocol(): ScoutProtocol = when (this) {
    ScannerProtocol.WIREGUARD -> ScoutProtocol.WIREGUARD
    ScannerProtocol.AMNEZIAWG -> ScoutProtocol.AMNEZIAWG
    ScannerProtocol.MASQUE -> ScoutProtocol.MASQUE
    ScannerProtocol.MASQUE_H2 -> ScoutProtocol.MASQUE_H2
}

private fun ScannerMode.toScoutMode(): ScoutMode = when (this) {
    ScannerMode.STANDARD -> ScoutMode.STANDARD
    ScannerMode.DURABLE -> ScoutMode.DURABLE
    ScannerMode.FULL -> ScoutMode.FULL
}

private fun IpVersion.toScoutIpVersion(): ScoutIpVersion =
    if (this == IpVersion.V6) ScoutIpVersion.V6 else ScoutIpVersion.V4

private fun ScoutResult.toUi(): ScoutEndpoint = ScoutEndpoint(
    endpoint = endpoint,
    endpointPing = if (endpointPingMs > 0) "${endpointPingMs.toInt()}ms" else "?",
    tunnelPing = if (tunPingMeasured) "${tunPingMs.toInt()}ms" else "-",
    loss = if (tunPingMeasured) "${lossPct.toInt()}%" else "-",
    seenAs = seenAsIso.ifBlank { seenAs },
    node = node,
    nodeLocation = nodeLocation,
    healthy = working,
)

private sealed class ScanUiState {
    data object Idle : ScanUiState()
    data object Registering : ScanUiState()
    data object Scanning : ScanUiState()
    data class Done(val endpoints: List<ScoutEndpoint>, val probed: Int) : ScanUiState()
    data class Failed(val message: String) : ScanUiState()
}

@Composable
private fun EndpointScannerScreen(
    runner: WarpScoutRunner,
    profileStore: ProfileStore,
    onBack: () -> Unit,
) {
    var protocol by remember { mutableStateOf(ScannerProtocol.MASQUE) }
    var advanced by remember { mutableStateOf(false) }
    var scanMode by remember { mutableStateOf(ScannerMode.STANDARD) }
    var ipVersion by remember { mutableStateOf(IpVersion.V4) }
    var port by remember { mutableStateOf("") }
    var genI1Quic by remember { mutableStateOf(false) }
    var uiState by remember { mutableStateOf<ScanUiState>(ScanUiState.Idle) }
    val scope = rememberCoroutineScope()

    val results = (uiState as? ScanUiState.Done)?.endpoints.orEmpty()
    val working = results.count { it.healthy }
    val countries = results.filter { it.healthy }.map { it.seenAs }.distinct().count()
    val bestPing = results.filter { it.healthy }
        .mapNotNull { it.tunnelPing.removeSuffix("ms").toIntOrNull() ?: it.endpointPing.removeSuffix("ms").toIntOrNull() }
        .minOrNull()?.let { "${it}ms" } ?: "-"
    val scanning = uiState is ScanUiState.Registering || uiState is ScanUiState.Scanning

    fun startScan() {
        if (!protocol.isScoutable() || scanning) return
        uiState = ScanUiState.Registering
        scope.launch {
            val opts = ScoutOptions(
                protocol = protocol.toScoutProtocol(),
                mode = scanMode.toScoutMode(),
                ipVersion = ipVersion.toScoutIpVersion(),
                port = port.toIntOrNull(),
                genI1 = if (protocol == ScannerProtocol.AMNEZIAWG && genI1Quic) {
                    ScoutI1Profile.QUIC
                } else {
                    null
                },
            )
            val outcome = withContext(Dispatchers.IO) {
                runner.ensureRegistered()
                    .onFailure { DiagnosticsLog.e("scout", "register failed: ${it.message}") }
                    .mapCatching {
                        runner.scan(opts).getOrThrow()
                    }
            }
            uiState = outcome.fold(
                onSuccess = { report ->
                    ScanUiState.Done(report.results.map { it.toUi() }, report.probedCount)
                },
                onFailure = { ScanUiState.Failed(it.message ?: "Scan failed") },
            )
        }
    }

    fun useEndpoint(endpoint: ScoutEndpoint) {
        scope.launch {
            val current = profileStore.profile.first()
            profileStore.save(
                current.copy(
                    protocol = when (protocol) {
                        ScannerProtocol.MASQUE -> ModelProtocol.MASQUE
                        ScannerProtocol.MASQUE_H2 -> ModelProtocol.MASQUE
                        ScannerProtocol.WIREGUARD, ScannerProtocol.AMNEZIAWG ->
                            ModelProtocol.WIREGUARD
                    },
                    masqueHttp2 = protocol == ScannerProtocol.MASQUE_H2,
                    noize = if (protocol == ScannerProtocol.AMNEZIAWG && current.noize == Noize.OFF) {
                        Noize.FIREWALL
                    } else {
                        current.noize
                    },
                    endpointMode = EndpointMode.MANUAL_PEER,
                    manualPeer = endpoint.endpoint,
                ),
            )
            onBack()
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            item {
                ScannerHero(onBack = onBack)
            }
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                ) {
                    Text(
                        text = stringResource(R.string.scanner_protocol),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                    SegmentedSelector(
                        options = ScannerProtocol.entries,
                        selected = protocol,
                        onSelect = { protocol = it },
                        label = { it.label() },
                    )
                    AnimatedVisibility(visible = protocol == ScannerProtocol.AMNEZIAWG) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.scanner_gen_i1_quic),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = stringResource(R.string.scanner_gen_i1_quic_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(checked = genI1Quic, onCheckedChange = { genI1Quic = it })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    AdvancedSearchCard(
                        expanded = advanced,
                        onExpandedChange = { advanced = it },
                        scanMode = scanMode,
                        onScanModeChange = { scanMode = it },
                        protocol = protocol,
                        onProtocolChange = { protocol = it },
                        ipVersion = ipVersion,
                        onIpVersionChange = { ipVersion = it },
                        port = port,
                        onPortChange = { port = it.filter(Char::isDigit).take(5) },
                    )
                    Spacer(Modifier.height(16.dp))
                    val probed = (uiState as? ScanUiState.Done)?.probed ?: 0
                    StatsStrip(tested = probed, working = working, countries = countries, bestPing = bestPing)
                    Spacer(Modifier.height(16.dp))
                    if (uiState is ScanUiState.Failed) {
                        Text(
                            text = (uiState as ScanUiState.Failed).message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                    }
                    OutlinedButton(
                        onClick = { startScan() },
                        enabled = protocol.isScoutable() && !scanning,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (scanning) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Text(
                                text = "  " + if (uiState is ScanUiState.Registering) {
                                    stringResource(R.string.scanner_registering)
                                } else {
                                    stringResource(R.string.scanner_scanning)
                                },
                            )
                        } else {
                            Icon(Icons.Rounded.Radar, contentDescription = null)
                            Text(text = "  " + stringResource(R.string.scanner_start))
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
            items(results, key = { it.endpoint }) { endpoint ->
                EndpointResultCard(
                    endpoint = endpoint,
                    onUse = { useEndpoint(endpoint) },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun AdvancedSearchCard(
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    scanMode: ScannerMode,
    onScanModeChange: (ScannerMode) -> Unit,
    protocol: ScannerProtocol,
    onProtocolChange: (ScannerProtocol) -> Unit,
    ipVersion: IpVersion,
    onIpVersionChange: (IpVersion) -> Unit,
    port: String,
    onPortChange: (String) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f),
        ),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(
                            text = stringResource(R.string.scanner_advanced),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = stringResource(R.string.scanner_advanced_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Switch(checked = expanded, onCheckedChange = onExpandedChange)
            }

            AnimatedVisibility(visible = expanded) {
                Column(Modifier.padding(top = 16.dp)) {
                    Text(
                        text = stringResource(R.string.scanner_test_type),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                    DropdownSelector(
                        options = ScannerMode.entries,
                        selected = scanMode,
                        onSelect = onScanModeChange,
                        label = { it.label() },
                    )
                    Text(
                        text = scanMode.description(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    Spacer(Modifier.height(14.dp))

                    Text(
                        text = stringResource(R.string.scanner_test_protocol),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                    DropdownSelector(
                        options = ScannerProtocol.entries,
                        selected = protocol,
                        onSelect = onProtocolChange,
                        label = { it.label() },
                    )
                    Spacer(Modifier.height(14.dp))

                    Text(
                        text = stringResource(R.string.scanner_ip_protocol),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                    SegmentedSelector(
                        options = IpVersion.entries,
                        selected = ipVersion,
                        onSelect = onIpVersionChange,
                        label = { it.label() },
                    )
                    Spacer(Modifier.height(14.dp))

                    LtrOutlinedTextField(
                        value = port,
                        onValueChange = onPortChange,
                        singleLine = true,
                        label = { Text(stringResource(R.string.scanner_port)) },
                        placeholder = { Text(stringResource(R.string.scanner_port_hint)) },
                        supportingText = { Text(stringResource(R.string.scanner_port_desc)) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

@Composable
private fun ScannerHero(onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF071326),
                        Color(0xFF0B1F32),
                        MaterialTheme.colorScheme.background,
                    ),
                ),
            ),
    ) {
        RadarCanvas(modifier = Modifier.fillMaxSize())
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .statusBarsPadding()
                .padding(8.dp),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = stringResource(R.string.back),
                tint = Color.White,
            )
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Public, contentDescription = null, tint = AetherCyan)
                Text(
                    text = "  " + stringResource(R.string.scanner_subtitle),
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFFB9D7FF),
                )
            }
            Text(
                text = stringResource(R.string.scanner_title),
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}

@Composable
private fun RadarCanvas(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "radar")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2600), RepeatMode.Restart),
        label = "sweep",
    )
    val pulse by transition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "pulse",
    )
    Canvas(modifier = modifier) {
        val center = Offset(size.width * 0.72f, size.height * 0.43f)
        val radius = size.minDimension * 0.34f * pulse
        repeat(4) { i ->
            drawCircle(
                color = AetherBlue.copy(alpha = 0.08f + i * 0.025f),
                radius = radius * (i + 1) / 4f,
                center = center,
                style = Stroke(width = 2.dp.toPx()),
            )
        }
        drawArc(
            brush = Brush.sweepGradient(listOf(Color.Transparent, AetherCyan.copy(alpha = 0.75f))),
            startAngle = sweep,
            sweepAngle = 72f,
            useCenter = true,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
        )
        listOf(
            Offset(center.x - radius * 0.35f, center.y + radius * 0.18f),
            Offset(center.x + radius * 0.24f, center.y - radius * 0.32f),
            Offset(center.x + radius * 0.48f, center.y + radius * 0.36f),
        ).forEach {
            drawCircle(AetherSuccess.copy(alpha = 0.9f), 4.dp.toPx(), it)
        }
        drawLine(
            color = AetherCyan.copy(alpha = 0.7f),
            start = center,
            end = Offset(
                center.x + kotlin.math.cos(Math.toRadians(sweep.toDouble())).toFloat() * radius,
                center.y + kotlin.math.sin(Math.toRadians(sweep.toDouble())).toFloat() * radius,
            ),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round,
        )
    }
}

@Composable
private fun StatsStrip(tested: Int, working: Int, countries: Int, bestPing: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        StatCard(stringResource(R.string.scanner_tested), tested.toString(), Modifier.weight(1f))
        StatCard(stringResource(R.string.scanner_working), working.toString(), Modifier.weight(1f))
        StatCard(stringResource(R.string.scanner_countries), countries.toString(), Modifier.weight(1f))
        StatCard(stringResource(R.string.scanner_best), bestPing, Modifier.weight(1f))
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun EndpointResultCard(
    endpoint: ScoutEndpoint,
    onUse: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(enabled = endpoint.healthy, onClick = onUse),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(if (endpoint.healthy) AetherSuccess else Color(0xFFFFB020), CircleShape),
                )
                Text(
                    text = endpoint.endpoint,
                    style = MaterialTheme.typography.titleMedium.copy(textDirection = TextDirection.Ltr),
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .padding(start = 10.dp)
                        .weight(1f),
                )
                Icon(Icons.Rounded.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Metric(R.string.scanner_ep_ping, endpoint.endpointPing)
                Metric(R.string.scanner_tun_ping, endpoint.tunnelPing)
                Metric(R.string.scanner_loss, endpoint.loss)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${endpoint.seenAs}  ${endpoint.node}".trim(),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = endpoint.nodeLocation,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Metric(labelRes: Int, value: String) {
    Column {
        Text(text = stringResource(labelRes), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ScannerProtocol.label(): String = when (this) {
    ScannerProtocol.MASQUE -> stringResource(R.string.protocol_masque)
    ScannerProtocol.MASQUE_H2 -> stringResource(R.string.scanner_protocol_masque_h2)
    ScannerProtocol.WIREGUARD -> stringResource(R.string.protocol_wireguard)
    ScannerProtocol.AMNEZIAWG -> stringResource(R.string.scanner_protocol_awg)
}

@Composable
private fun ScannerMode.label(): String = when (this) {
    ScannerMode.STANDARD -> stringResource(R.string.scanner_mode_standard)
    ScannerMode.DURABLE -> stringResource(R.string.scanner_mode_durable)
    ScannerMode.FULL -> stringResource(R.string.scanner_mode_full)
}

@Composable
private fun ScannerMode.description(): String = when (this) {
    ScannerMode.STANDARD -> stringResource(R.string.scanner_mode_standard_desc)
    ScannerMode.DURABLE -> stringResource(R.string.scanner_mode_durable_desc)
    ScannerMode.FULL -> stringResource(R.string.scanner_mode_full_desc)
}

@Composable
private fun IpVersion.label(): String = when (this) {
    IpVersion.V4 -> stringResource(R.string.ip_v4)
    IpVersion.V6 -> stringResource(R.string.ip_v6)
    IpVersion.BOTH -> stringResource(R.string.ip_both)
}